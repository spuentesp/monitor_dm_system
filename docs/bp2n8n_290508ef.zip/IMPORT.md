# Import manual en n8n

## Opción recomendada: CLI de n8n (conserva los vínculos)

Los workflows traen IDs determinísticos: los nodos *Execute Workflow*
y el *error workflow* de cada proceso ya quedan conectados.

```bash
# en el servidor donde corre n8n (o dentro del contenedor):
n8n import:workflow --separate --input=/ruta/a/esta/carpeta
```

## Opción UI: Workflows → Import from File

La UI asigna IDs nuevos al importar, así que los vínculos no se
conservan solos. Orden recomendado:

1. Importar primero los subworkflows (`:: <subsheet>`) y el
   `:: Error Handler` de cada proceso.
2. Importar el workflow principal al final.
3. En cada nodo *Execute Workflow*, re-seleccionar el destino en el
   picker — el nombre correcto ya aparece como etiqueta del nodo.
4. En el workflow principal: *Settings → Error Workflow* → elegir el
   `:: Error Handler` del proceso.

## Después de importar (cualquier opción)

- Crear las credenciales en *n8n → Credentials* (el reporte de
  migración lista los nombres; los valores nunca se exportan).
- Cargar las variables de entorno (`01_parsed/env_vars.yaml`).
- Conectar los nodos `Notificar` (placeholder) a Slack/Email.
- Resolver la cola de revisión (`review_queue.md`) antes de activar.

## Inventario

| Workflow | Archivo | ID |
|---|---|---|
| [BP] API Gmail - Obtencion de Token | `bp_api_gmail_obtencion_de_token_c4536ace.workflow.json` | `c4536acebc5b47e1` |
| [BP] API Gmail - Obtencion de Token :: API Gmail | `bp_api_gmail_obtencion_de_token_api_gmail_a2a8fa93.workflow.json` | `a2a8fa930e42dc90` |
| [BP] API Gmail - Obtencion de Token :: Check Token Status | `bp_api_gmail_obtencion_de_token_check_token_status_6d81917d.workflow.json` | `6d81917dd9f90b1f` |
| [BP] API Gmail - Obtencion de Token :: Consent Drive | `bp_api_gmail_obtencion_de_token_consent_drive_4eca7ff1.workflow.json` | `4eca7ff1fdd55618` |
| [BP] API Gmail - Obtencion de Token :: #Login GDrive | `bp_api_gmail_obtencion_de_token_login_gdrive_00c7ecce.workflow.json` | `00c7ecce60286d56` |
| [BP] API Gmail - Obtencion de Token :: Error Handler | `bp_api_gmail_obtencion_de_token_error_handler_546605f9.workflow.json` | `546605f9ce5c13c7` |
| [BP] Login Agent - Main | `bp_login_agent_main_6c0e79cf.workflow.json` | `6c0e79cf6be7a0b0` |
| [BP] Login Agent - Main :: Error Handler | `bp_login_agent_main_error_handler_a3a1b382.workflow.json` | `a3a1b382424b1481` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_e1872a61.workflow.json` | `e1872a61cf56de37` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse :: Consolidar | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_e97bf467.workflow.json` | `e97bf4670aac1548` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse :: Obtener Pendientes | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_bed2149a.workflow.json` | `bed2149a326c1005` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse :: #Obtener Rut | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_4aa228cd.workflow.json` | `4aa228cd2c82bb6b` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse :: Notificar - Error | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_dac6101a.workflow.json` | `dac6101a9455d124` |
| [BP] Operaciones Pendientes de Curse - Consolidar Operaciones Pendientes de Curse :: Error Handler | `bp_operaciones_pendientes_de_curse_consolidar_operaciones_pe_44454333.workflow.json` | `4445433381fd0be3` |
| [BP] Operaciones Pendientes de Curse - Main | `bp_operaciones_pendientes_de_curse_main_86eeafd6.workflow.json` | `86eeafd62a0b1b3b` |
| [BP] Operaciones Pendientes de Curse - Main :: Start Up | `bp_operaciones_pendientes_de_curse_main_start_up_3583570b.workflow.json` | `3583570b7ea63b49` |
| [BP] Operaciones Pendientes de Curse - Main :: #Fin Log | `bp_operaciones_pendientes_de_curse_main_fin_log_fb3b66b1.workflow.json` | `fb3b66b1dc4b8b35` |
| [BP] Operaciones Pendientes de Curse - Main :: Load Queue | `bp_operaciones_pendientes_de_curse_main_load_queue_c874245d.workflow.json` | `c874245d8f9c7ab5` |
| [BP] Operaciones Pendientes de Curse - Main :: #Iniciar Log | `bp_operaciones_pendientes_de_curse_main_iniciar_log_81b1465d.workflow.json` | `81b1465dcec3e53e` |
| [BP] Operaciones Pendientes de Curse - Main :: Get Next Item | `bp_operaciones_pendientes_de_curse_main_get_next_item_1ce55505.workflow.json` | `1ce555053fe4894e` |
| [BP] Operaciones Pendientes de Curse - Main :: Buscar datos a cargar | `bp_operaciones_pendientes_de_curse_main_buscar_datos_a_carga_eb9c85ef.workflow.json` | `eb9c85ef58a2da08` |
| [BP] Operaciones Pendientes de Curse - Main :: Close Down | `bp_operaciones_pendientes_de_curse_main_close_down_3a5ed1f3.workflow.json` | `3a5ed1f35d33e299` |
| [BP] Operaciones Pendientes de Curse - Main :: Mark Item As Completed | `bp_operaciones_pendientes_de_curse_main_mark_item_as_complet_092f980c.workflow.json` | `092f980c2859ec82` |
| [BP] Operaciones Pendientes de Curse - Main :: Mark Item As Exception | `bp_operaciones_pendientes_de_curse_main_mark_item_as_excepti_c0e59af9.workflow.json` | `c0e59af984b9c8db` |
| [BP] Operaciones Pendientes de Curse - Main :: Notificar | `bp_operaciones_pendientes_de_curse_main_notificar_5d8efe31.workflow.json` | `5d8efe31e3165b7e` |
| [BP] Operaciones Pendientes de Curse - Main :: #Reportar Ejecucion | `bp_operaciones_pendientes_de_curse_main_reportar_ejecucion_04b01984.workflow.json` | `04b01984222213ab` |
| [BP] Operaciones Pendientes de Curse - Main :: Error Handler | `bp_operaciones_pendientes_de_curse_main_error_handler_dfb0f15c.workflow.json` | `dfb0f15c7296a066` |
| [BP] Operaciones Pendientes de Curse - SMTP Obtener Archivo Excel | `bp_operaciones_pendientes_de_curse_smtp_obtener_archivo_exce_77abf349.workflow.json` | `77abf3494605b7cb` |
| [BP] Operaciones Pendientes de Curse - SMTP Obtener Archivo Excel :: Get Excel Name | `bp_operaciones_pendientes_de_curse_smtp_obtener_archivo_exce_1e080412.workflow.json` | `1e08041243f3eba6` |
| [BP] Operaciones Pendientes de Curse - SMTP Obtener Archivo Excel :: Notificar - Error | `bp_operaciones_pendientes_de_curse_smtp_obtener_archivo_exce_2e0f3d14.workflow.json` | `2e0f3d14924e6227` |
| [BP] Operaciones Pendientes de Curse - SMTP Obtener Archivo Excel :: Error Handler | `bp_operaciones_pendientes_de_curse_smtp_obtener_archivo_exce_f5628270.workflow.json` | `f5628270318a9223` |
| [BP] Operaciones Pendientes de Cuse - Envio de Correo | `bp_operaciones_pendientes_de_cuse_envio_de_correo_f528f4b1.workflow.json` | `f528f4b135cf087a` |
| [BP] Operaciones Pendientes de Cuse - Envio de Correo :: Notificar | `bp_operaciones_pendientes_de_cuse_envio_de_correo_notificar_91390dd1.workflow.json` | `91390dd1dfa9fc55` |
| [BP] Operaciones Pendientes de Cuse - Envio de Correo :: Error Handler | `bp_operaciones_pendientes_de_cuse_envio_de_correo_error_hand_5baf9870.workflow.json` | `5baf98709aaaf3cc` |
| [BP] Queue Manager | `bp_queue_manager_b884ceb5.workflow.json` | `b884ceb54de12de7` |

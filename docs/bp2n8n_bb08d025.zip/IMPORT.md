# Import manual en n8n

## Opción recomendada: CLI de n8n (conserva los vínculos)

Los workflows traen IDs determinísticos: los nodos *Execute Workflow*
y el *error workflow* de cada proceso ya quedan conectados.

```bash
# en el servidor donde corre n8n (o dentro del contenedor):
n8n import:workflow --separate --input=/ruta/a/esta/carpeta
```

## Opción UI: Workflows → Import from File

La UI asigna IDs nuevos al importar, así que los vínculos no se
conservan solos. Orden recomendado:

1. Importar primero los subworkflows (`:: <subsheet>`) y el
   `:: Error Handler` de cada proceso.
2. Importar el workflow principal al final.
3. En cada nodo *Execute Workflow*, re-seleccionar el destino en el
   picker — el nombre correcto ya aparece como etiqueta del nodo.
4. En el workflow principal: *Settings → Error Workflow* → elegir el
   `:: Error Handler` del proceso.

## Después de importar (cualquier opción)

- Crear las credenciales en *n8n → Credentials* (el reporte de
  migración lista los nombres; los valores nunca se exportan).
- Cargar las variables de entorno (`01_parsed/env_vars.yaml`).
- Conectar los nodos `Notificar` (placeholder) a Slack/Email.
- Resolver la cola de revisión (`review_queue.md`) antes de activar.

## Inventario

| Workflow | Archivo | ID |
|---|---|---|
| [BP] Operaciones Pendientes de Curse - Main | `bp_operaciones_pendientes_de_curse_main_86eeafd6.workflow.json` | `86eeafd62a0b1b3b` |
| [BP] Operaciones Pendientes de Curse - Main :: Start Up | `bp_operaciones_pendientes_de_curse_main_start_up_3583570b.workflow.json` | `3583570b7ea63b49` |
| [BP] Operaciones Pendientes de Curse - Main :: #Fin Log | `bp_operaciones_pendientes_de_curse_main_fin_log_fb3b66b1.workflow.json` | `fb3b66b1dc4b8b35` |
| [BP] Operaciones Pendientes de Curse - Main :: Load Queue | `bp_operaciones_pendientes_de_curse_main_load_queue_c874245d.workflow.json` | `c874245d8f9c7ab5` |
| [BP] Operaciones Pendientes de Curse - Main :: #Iniciar Log | `bp_operaciones_pendientes_de_curse_main_iniciar_log_81b1465d.workflow.json` | `81b1465dcec3e53e` |
| [BP] Operaciones Pendientes de Curse - Main :: Get Next Item | `bp_operaciones_pendientes_de_curse_main_get_next_item_1ce55505.workflow.json` | `1ce555053fe4894e` |
| [BP] Operaciones Pendientes de Curse - Main :: Buscar datos a cargar | `bp_operaciones_pendientes_de_curse_main_buscar_datos_a_carga_eb9c85ef.workflow.json` | `eb9c85ef58a2da08` |
| [BP] Operaciones Pendientes de Curse - Main :: Close Down | `bp_operaciones_pendientes_de_curse_main_close_down_3a5ed1f3.workflow.json` | `3a5ed1f35d33e299` |
| [BP] Operaciones Pendientes de Curse - Main :: Mark Item As Completed | `bp_operaciones_pendientes_de_curse_main_mark_item_as_complet_092f980c.workflow.json` | `092f980c2859ec82` |
| [BP] Operaciones Pendientes de Curse - Main :: Mark Item As Exception | `bp_operaciones_pendientes_de_curse_main_mark_item_as_excepti_c0e59af9.workflow.json` | `c0e59af984b9c8db` |
| [BP] Operaciones Pendientes de Curse - Main :: Notificar | `bp_operaciones_pendientes_de_curse_main_notificar_5d8efe31.workflow.json` | `5d8efe31e3165b7e` |
| [BP] Operaciones Pendientes de Curse - Main :: #Reportar Ejecucion | `bp_operaciones_pendientes_de_curse_main_reportar_ejecucion_04b01984.workflow.json` | `04b01984222213ab` |
| [BP] Operaciones Pendientes de Curse - Main :: Error Handler | `bp_operaciones_pendientes_de_curse_main_error_handler_dfb0f15c.workflow.json` | `dfb0f15c7296a066` |
| [BP] Queue Manager | `bp_queue_manager_b884ceb5.workflow.json` | `b884ceb54de12de7` |
